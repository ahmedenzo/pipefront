import { HttpErrorResponse, HttpEvent, HttpHandlerFn, HttpRequest } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from 'app/core/auth/auth.service';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';

export const authInterceptor = (req: HttpRequest<unknown>, next: HttpHandlerFn): Observable<HttpEvent<unknown>> => {
    const authService = inject(AuthService);
    const router = inject(Router);

    // Clone the request and include withCredentials to allow sending cookies
    let newReq = req.clone({
        withCredentials: true  // This ensures that the refresh token (if stored as a cookie) is sent
    });

    // Add Authorization header if access token is valid
    const accessToken = authService.accessToken;
    if (accessToken) {
        newReq = newReq.clone({
            headers: newReq.headers.set('Authorization', 'Bearer ' + accessToken),
            withCredentials: true
        });
    }

    return next(newReq).pipe(
        catchError((error) => {
            // If the error is a 401 Unauthorized or 403 Forbidden, attempt to refresh the token
            if (error instanceof HttpErrorResponse && (error.status === 401 || error.status === 403)) {

                // If user is not authenticated, redirect to sign-in page
                if (!authService.isAuthenticated()) {
                    authService.signOut().subscribe(() => {
                        router.navigate(['/auth/sign-in']);
                    });
                    return throwError(error);
                }

                // Attempt to refresh the access token
                return authService.refreshAccessToken().pipe(
                    switchMap(() => {
                        // Get the new access token after refreshing
                        const newAccessToken = authService.accessToken;

                        // Clone the original request with the new access token
                        const clonedRequest = newReq.clone({
                            headers: newReq.headers.set('Authorization', 'Bearer ' + newAccessToken),
                            withCredentials: true
                        });

                        // Retry the request with the new token
                        return next(clonedRequest);
                    }),
                    catchError((refreshError) => {
                        // If token refresh fails, sign the user out and redirect to sign-in
                        console.error('Error refreshing access token:', refreshError);
                        authService.signOut().subscribe(() => {
                            router.navigate(['/auth/sign-in']);
                        });
                        return throwError(refreshError);
                    })
                );
            }

            // If any other error occurs, just propagate it
            return throwError(error);
        })
    );
};
