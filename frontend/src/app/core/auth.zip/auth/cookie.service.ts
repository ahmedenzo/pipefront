// src/app/core/services/cookie.service.ts

import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';

@Injectable({ providedIn: 'root' })
export class CookieService {
    private secretKey = 'e5b4c6d8f1a2b3c4d5e6f708192a3b4c'; // Replace with your actual secret key

    /**
     * Encrypt data using AES encryption
     * @param data Data to encrypt
     * @returns Encrypted string
     */
    private encrypt(data: string): string {
        return CryptoJS.AES.encrypt(data, this.secretKey).toString();
    }

    /**
     * Decrypt data using AES decryption
     * @param data Encrypted string
     * @returns Decrypted data
     */
    private decrypt(data: string): string {
        const bytes = CryptoJS.AES.decrypt(data, this.secretKey);
        return bytes.toString(CryptoJS.enc.Utf8);
    }

    /**
     * Set a cookie with encryption
     * @param name Name of the cookie
     * @param value Value of the cookie
     * @param days Number of days until the cookie expires
     */
    setCookie(name: string, value: any, days: number): void {
        const expires = new Date(Date.now() + days * 864e5).toUTCString();
        const encryptedValue = this.encrypt(JSON.stringify(value));
        document.cookie = `${name}=${encodeURIComponent(encryptedValue)}; expires=${expires}; path=/`;
    }

    /**
     * Get and decrypt a cookie by name
     * @param name Name of the cookie
     * @returns Decrypted value of the cookie or null if not found
     */
    getCookie(name: string): any {
        const cookies = document.cookie.split('; ');
        for (const cookie of cookies) {
            const [cookieName, cookieValue] = cookie.split('=');
            if (cookieName === name) {
                try {
                    const decryptedValue = this.decrypt(decodeURIComponent(cookieValue));
                    return JSON.parse(decryptedValue);
                } catch (error) {
                    console.error('Error decrypting cookie:', error);
                    this.deleteCookie(name);
                    return null;
                }
            }
        }
        return null;
    }

    /**
     * Delete a cookie by name
     * @param name Name of the cookie
     */
    deleteCookie(name: string): void {
        this.setCookie(name, '', -1);
    }
}
