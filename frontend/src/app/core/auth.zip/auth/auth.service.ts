// src/app/core/auth/auth.service.ts

import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { BehaviorSubject, catchError, map, Observable, of, switchMap, tap, throwError } from 'rxjs';
import { AuthUtils } from 'app/core/auth/auth.utils';
import { UserService } from 'app/core/user/user.service';
import { CookieService } from 'app/core/auth/cookie.service';
import { environment } from '../../../../environment.prod';

@Injectable({ providedIn: 'root' })
export class AuthService {
    private _authenticated: boolean = false;
    private _httpClient = inject(HttpClient);
    private _userService = inject(UserService);
    private _cookieService = inject(CookieService);
    private apiUrl = environment.apiUrl;
    private _alertSubject = new BehaviorSubject<string | null>(null);

    public alert$ = this._alertSubject.asObservable();

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Setter & getter for access token
     */
    set accessToken(token: string) {
        console.log('Setting access token:', token);
        try {
            localStorage.setItem('accessToken', token);
            console.log('Token stored in localStorage:', localStorage.getItem('accessToken'));
        } catch (e) {
            console.error('Error storing access token in localStorage:', e);
        }
    }

    get accessToken(): string {
        try {
            const token = localStorage.getItem('accessToken') ?? '';
            console.log('Getting access token:', token);
            return token;
        } catch (e) {
            console.error('Error getting access token from localStorage:', e);
            return '';
        }
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Check if the user is authenticated
     */
    isAuthenticated(): boolean {
        return this._authenticated;
    }

    /**
     * Trigger an alert to display to the user
     * @param message
     */
    triggerAlert(message: string): void {
        this._alertSubject.next(message);
    }

    /**
     * Sign in
     *
     * @param credentials { username, password }
     */
    signIn(credentials: { username: string; password: string }): Observable<any> {
        if (this._authenticated) {
            return throwError(() => new Error('User is already logged in.'));
        }

        return this._httpClient.post(`${this.apiUrl}/api/auth/signin`, credentials, { withCredentials: true }).pipe(
            switchMap((response: any) => {
                console.log('Sign-in response:', response);

                const token = response.token;

                if (!token) {
                    return throwError(() => new Error('Access token is missing from the response.'));
                }

                // Set the access token
                this.accessToken = token;

                this._authenticated = true;

                // Prepare the user data
                const userData = {
                    id: response.id,
                    username: response.username,
                    adminId: response.adminId,
                    agencyId: response.agencyId,
                    bankId: response.bankId,
                    roles: response.roles,
                    sessionId: response.sessionId,
                    // Include any other fields you need
                };

                // Store user data
                this._userService.user = userData;
                this._cookieService.setCookie('user', userData, 7); // Store in cookie for 7 days

                return of(response);
            }),
            catchError((error) => {
                console.error('Error during sign-in:', error);
                this.triggerAlert('Wrong username or password. Please try again.');
                this._authenticated = false;
                return throwError(error);
            })
        );
    }

    /**
     * Sign out
     */
    signOut(): Observable<any> {
        const accessToken = this.accessToken;

        // Clear authentication state and tokens
        this._authenticated = false;
        localStorage.removeItem('accessToken');

        // Clear user data if stored in UserService and cookies
        this._userService.clearUserData();
        this._cookieService.deleteCookie('user');

        console.log('Signing out...');

        // Optionally, you can call a sign-out endpoint on the server
        return of(true);
    }

    /**
     * Check the authentication status
     */
    check(): Observable<boolean> {
        console.log('AuthService.check() called');

        if (this._authenticated) {
            console.log('User is already authenticated.');
            return of(true);
        }

        if (!this.accessToken || AuthUtils.isTokenExpired(this.accessToken)) {
            console.log('Access token is missing or expired.');

            // Attempt to refresh the access token using the refresh token
            return this.refreshAccessToken().pipe(
                map(() => {
                    console.log('Access token refreshed successfully.');
                    return true;
                }),
                catchError((error) => {
                    console.error('Failed to refresh access token:', error);
                    // Sign out the user if refresh token is invalid or expired
                    this.signOut().subscribe();
                    return of(false);
                })
            );
        }

        console.log('Access token is valid.');
        this._authenticated = true;
        return of(true);
    }

    /**
     * Refresh the access token using the refresh token
     */
    refreshAccessToken(): Observable<any> {
        console.log('AuthService.refreshAccessToken() called');

        return this._httpClient.post(`${this.apiUrl}/api/auth/refreshToken`, {}, { withCredentials: true }).pipe(
            switchMap((response: any) => {
                console.log('Refresh token response received:', response);

                const newAccessToken = response.token;

                if (!newAccessToken) {
                    console.error('Invalid token response.');
                    return throwError(() => new Error('Invalid token response.'));
                }

                this.accessToken = newAccessToken;
                this._authenticated = true;

                return of(response);
            }),
            catchError((error: HttpErrorResponse) => {
                console.error('Error during token refresh:', error);
                // Sign out the user if refresh token is invalid or expired
                this.signOut().subscribe();
                return throwError(error);
            })
        );
    }

    /**
     * Handle unauthorized errors (e.g., invalid or expired tokens)
     */
    private _handleUnauthorized(error: any): Observable<any> {
        console.error('Unauthorized error:', error);
        // Sign out the user
        this.signOut().subscribe();
        return of(false);
    }

    /**
     * Forgot password
     *
     * @param email
     */
    forgotPassword(email: string): Observable<any> {
        return this._httpClient.post('api/auth/forgot-password', email);
    }

    /**
     * Reset password
     *
     * @param password
     */
    resetPassword(password: string): Observable<any> {
        return this._httpClient.post('api/auth/reset-password', password);
    }

    /**
     * Sign up
     *
     * @param user
     */
    signUp(user: { name: string; email: string; password: string; company: string }): Observable<any> {
        return this._httpClient.post('api/auth/sign-up', user);
    }

    /**
     * Unlock session
     *
     * @param credentials
     */
    unlockSession(credentials: { username: string; password: string }): Observable<any> {
        return this._httpClient.post('api/auth/unlock-session', credentials);
    }
}
